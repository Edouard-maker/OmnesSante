-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 24 mai 2022 à 13:24
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `omnessante`
--

-- --------------------------------------------------------

--
-- Structure de la table `acte`
--

DROP TABLE IF EXISTS `acte`;
CREATE TABLE IF NOT EXISTS `acte` (
  `type` text,
  `professionnel` int(11) DEFAULT NULL,
  `patient` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `acte`
--

INSERT INTO `acte` (`type`, `professionnel`, `patient`) VALUES
('consultation', 1, '1 40 03 75 102 395'),
('examen', 4, '2 99 04 75 109 123');

-- --------------------------------------------------------

--
-- Structure de la table `administrateur`
--

DROP TABLE IF EXISTS `administrateur`;
CREATE TABLE IF NOT EXISTS `administrateur` (
  `login` text,
  `mdp` text,
  `nom` text,
  `prenom` text,
  `courriel` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `administrateur`
--

INSERT INTO `administrateur` (`login`, `mdp`, `nom`, `prenom`, `courriel`) VALUES
('admin', 'mdp', 'name', 'vorname', 'name.vorname@omnessante.fr');

-- --------------------------------------------------------

--
-- Structure de la table `calendrier`
--

DROP TABLE IF EXISTS `calendrier`;
CREATE TABLE IF NOT EXISTS `calendrier` (
  `consultation` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `consultation`
--

DROP TABLE IF EXISTS `consultation`;
CREATE TABLE IF NOT EXISTS `consultation` (
  `date` date DEFAULT NULL,
  `salle` int(11) DEFAULT NULL,
  `acte` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `consultation`
--

INSERT INTO `consultation` (`date`, `salle`, `acte`) VALUES
('2012-06-22', 3, '');

-- --------------------------------------------------------

--
-- Structure de la table `moyenpaiement`
--

DROP TABLE IF EXISTS `moyenpaiement`;
CREATE TABLE IF NOT EXISTS `moyenpaiement` (
  `banque` text,
  `nomTitulaire` text,
  `expiration` date DEFAULT NULL,
  `numero` text,
  `cvv` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `moyenpaiement`
--

INSERT INTO `moyenpaiement` (`banque`, `nomTitulaire`, `expiration`, `numero`, `cvv`) VALUES
('HSBC', 'RANDOM JEAN-EUDES', '2012-12-22', '0101 2562 2354 2525', 321);

-- --------------------------------------------------------

--
-- Structure de la table `patient`
--

DROP TABLE IF EXISTS `patient`;
CREATE TABLE IF NOT EXISTS `patient` (
  `login` text,
  `mdp` text,
  `nom` text,
  `prenom` text,
  `adresse` text,
  `courriel` text,
  `numSS` text,
  `moyenPaiement` text,
  `allergies` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `patient`
--

INSERT INTO `patient` (`login`, `mdp`, `nom`, `prenom`, `adresse`, `courriel`, `numSS`, `moyenPaiement`, `allergies`) VALUES
('pat', 'mdp', 'n', 'p', '7, rue d Alésia 75014 PARIS', 'n.p@gmail.fr', '1 01 05 75 110 123', 'visa', 'arachide');

-- --------------------------------------------------------

--
-- Structure de la table `professionnel`
--

DROP TABLE IF EXISTS `professionnel`;
CREATE TABLE IF NOT EXISTS `professionnel` (
  `id` int(11) DEFAULT NULL,
  `nom` text,
  `prenom` text,
  `photo` text,
  `secteur` text,
  `spe` text,
  `cv` text,
  `consult` date DEFAULT NULL,
  `dispordv` date DEFAULT NULL,
  `courriel` text,
  `enligne` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `professionnel`
--

INSERT INTO `professionnel` (`id`, `nom`, `prenom`, `photo`, `secteur`, `spe`, `cv`, `consult`, `dispordv`, `courriel`, `enligne`) VALUES
(1, 'Cabrol', 'Christian', '', 'spe', 'cardiologie', '1 er a avoir greffé un coeur !', '2012-12-12', '2026-05-22', 'cabrol.christian@omnessante.fr', 0),
(2, 'Joab', 'Nadine', '', 'generaliste', '', 'Médecin généraliste et pédiatre. A travaillé à la clinique Marie-Louise du 9e arrondissement de Paris', '2012-12-12', '2026-05-22', 'joab.nadine@omnessante.fr', 0),
(3, 'Random', 'Jean', '', 'spe', 'ostéopathe', 'Ecole d ostéopathie conventionnée, dont le diplôme est reconnu par l Etat français.', '2012-12-20', '2026-05-22', 'random.jean@omnessante.fr', 1),
(4, 'Trousselie', 'Isabelle', '', 'labo', '', 'Professionnelle de santé depuis 20 ans dans un laboratoire de biologie médicale. spécialiste dans les prélèvements sanguins et les sérologies', '2012-12-12', '2026-05-22', 'trousselie.isabelle@omnessante.fr', 0);

-- --------------------------------------------------------

--
-- Structure de la table `structure`
--

DROP TABLE IF EXISTS `structure`;
CREATE TABLE IF NOT EXISTS `structure` (
  `nom` text,
  `adresse` text,
  `telephone` text,
  `professionnel` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `structure`
--

INSERT INTO `structure` (`nom`, `adresse`, `telephone`, `professionnel`) VALUES
('Clinique Convention', '95, rue la Convention 75015 PARIS', '+33 1 40 35 26 44', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
