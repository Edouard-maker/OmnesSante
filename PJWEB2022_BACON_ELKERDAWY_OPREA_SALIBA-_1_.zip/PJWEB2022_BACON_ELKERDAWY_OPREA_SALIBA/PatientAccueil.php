<?php
include "config.php";

// Déconnexion
if (isset($_POST['but_logout'])) {
    session_destroy();
    header('Location: PatientLogin.php');
}
?>

<!doctype html>
<html>

<head>
    <meta charset="UTF-8">
    <title> Page Patient </title>
    <link href="bootstrap.min.css" rel="stylesheet" />
    <link href="Projet.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="logo.ico" rel="icon" type="x-icon" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
</head>

<body>
    <div class="wrapper">
        <div class="container-fluid header">
            <div class="row">
                <div class="col-md-2">
                    <br><img src="Projet-logo.png" height="110" width="110">
                </div>
                <div class="col-md-8">
                    <br>
                    <h1>
                        <li> OMNES SANTÉ </li>
                        <li> </li>
                    </h1>
                    <p>since 2022</p></br>
                </div>
            </div>
        </div>
        
        <h1 style="text-align: center; color: #071f32;"> Bienvenue sur votre page patient </h1>

        <div class="container-fluid ">
            <div class="row">
                <div class="col-md-2 section">
                   <br> <p>Que voulez-vous faire ?</p>
                    <p> <a class="btn btn-secondary btn-sm" href="chatP.php"> Chattez avec vos médecins </a> </p>
                    <form method='post' action="">
                        <input class="btn btn-secondary btn-sm" type="submit" value="Déconnexion" name="but_logout">
                    </form>
                </div>
            
                <div class="col-md-6">
                    <br><h2>Profil</h2>
                    Nom : 
                    <?php 
                    echo $_SESSION['nomClient'];
                    ?><br>Prénom :
                    <?php 
                    echo $_SESSION['prenomClient'];
                    ?><br>Adresse :
                    <?php 
                    echo $_SESSION['adresseClient'];
                    ?><br>Courriel :
                    <?php 
                    echo $_SESSION['courrielClient'];
                    ?><br>Numéro de sécurité sociale :
                    <?php 
                    echo $_SESSION['numSS'];
                    ?>
            </div>
        </div>

        
</body>

</html>