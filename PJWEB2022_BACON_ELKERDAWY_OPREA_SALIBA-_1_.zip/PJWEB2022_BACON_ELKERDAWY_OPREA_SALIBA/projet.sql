-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : dim. 29 mai 2022 à 19:58
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet`
--

-- --------------------------------------------------------

--
-- Structure de la table `administrateur`
--

DROP TABLE IF EXISTS `administrateur`;
CREATE TABLE IF NOT EXISTS `administrateur` (
  `mdpAdmin` varchar(20) NOT NULL,
  `nomAdmin` varchar(15) NOT NULL,
  `prenomAdmin` varchar(15) NOT NULL,
  `courrielAdmin` varchar(50) NOT NULL,
  `loginAdmin` varchar(50) NOT NULL,
  `numeroAdmin` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`numeroAdmin`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `administrateur`
--

INSERT INTO `administrateur` (`mdpAdmin`, `nomAdmin`, `prenomAdmin`, `courrielAdmin`, `loginAdmin`, `numeroAdmin`) VALUES
('mdp', 'Beos', 'Arem', 'arem.beos@mail.com', 'admin', 1);

-- --------------------------------------------------------

--
-- Structure de la table `cartebancaire`
--

DROP TABLE IF EXISTS `cartebancaire`;
CREATE TABLE IF NOT EXISTS `cartebancaire` (
  `nomCarte` varchar(50) NOT NULL,
  `banque` varchar(30) NOT NULL,
  `expiration` date NOT NULL,
  `numero` varchar(16) NOT NULL,
  `cvv` int(3) NOT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cartebancaire`
--

INSERT INTO `cartebancaire` (`nomCarte`, `banque`, `expiration`, `numero`, `cvv`) VALUES
('JACQUELINE DUPONT', 'LCI', '2001-06-22', '0000111100001111', 123),
('CHARLES FRED', 'CREDIT MUTUEL', '2001-06-23', '0000221100333111', 159),
('CHRISTOPHE VALLET', 'BNP', '2001-09-23', '0095111100251111', 658),
('MELINA KARAPETIAN', 'HSBC', '2001-07-24', '0923111125038411', 153),
('SIMON DUDAMEL', 'CAISSE D EPARGNE', '2001-06-24', '1200654100025251', 168),
('ANTOINE BRETON', 'SOCIETE GENERALE', '2001-03-24', '0001234509871111', 751),
('PATRICIA PISANU', 'HSBC', '2001-12-24', '4971111100851124', 647),
('LUCAS DUPLEISSIER', 'LCI', '2001-08-23', '2201471166301871', 3);

-- --------------------------------------------------------

--
-- Structure de la table `centre`
--

DROP TABLE IF EXISTS `centre`;
CREATE TABLE IF NOT EXISTS `centre` (
  `nom` varchar(20) DEFAULT NULL,
  `adresse` varchar(50) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `numeroCentre` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`numeroCentre`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `centre`
--

INSERT INTO `centre` (`nom`, `adresse`, `telephone`, `numeroCentre`) VALUES
('Charles de Gaulle', '3 rue de la Paprasse 78 000 Surenes', '+33 6 44 44 44 44', 1),
('Zola', '88 avenue de la Paroisse 92 001 Puteaux', '+33 6 22 22 22 22', 8),
('Jules Vernes', '45 bis rue de la Rose 78 009 Houilles', '+33 6 55 55 55 55', 3),
('Victor Hugo ', '33 impasse du Colibri 75 001 Paris', '+33 6 33 33 33 33', 4),
('Picasso', '3 boulevard Jeanne d\'Arc 78 000 Cergy', '+33 6 88 88 88 88', 7);

-- --------------------------------------------------------

--
-- Structure de la table `consultation`
--

DROP TABLE IF EXISTS `consultation`;
CREATE TABLE IF NOT EXISTS `consultation` (
  `dateheure` datetime DEFAULT NULL,
  `salle` varchar(10) DEFAULT NULL,
  `acte` varchar(100) DEFAULT NULL,
  `numeroCons` int(11) NOT NULL AUTO_INCREMENT,
  `client` varchar(20) DEFAULT NULL,
  `medecin` varchar(20) DEFAULT NULL,
  `centre` varchar(50) NOT NULL,
  PRIMARY KEY (`numeroCons`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `consultation`
--

INSERT INTO `consultation` (`dateheure`, `salle`, `acte`, `numeroCons`, `client`, `medecin`, `centre`) VALUES
('2022-05-30 13:30:00', '6', 'consultation', 2, NULL, 'Trousselle', 'Victor Hugo'),
('2022-05-31 16:00:00', '4', 'test covid', 3, 'Dupont', 'Joab', 'Picasso'),
('2022-05-30 17:00:00', '349', NULL, 4, 'Fred', 'Cabrol', 'Picasso'),
('2022-05-31 18:00:00', '456', NULL, 5, NULL, 'Cabrol', 'Picasso'),
('2022-05-29 16:11:33', '348', 'Prise de sang ', 6, NULL, 'Lesage', 'Picasso '),
('2022-05-29 16:11:33', '567', 'Consultation de routine', 7, NULL, 'Sorre', 'Picasso'),
('2022-05-29 16:14:07', '123', 'Cardiogramme', 8, NULL, 'Cabrol', 'Jules Vernes'),
('2022-05-29 16:14:07', '789', 'Test urinaire', 9, NULL, 'Padrelle', 'Zola'),
('2022-05-29 16:16:02', '4567', 'Tendon', 10, 'Fred', 'Jordan', 'Zola');

-- --------------------------------------------------------

--
-- Structure de la table `medecin`
--

DROP TABLE IF EXISTS `medecin`;
CREATE TABLE IF NOT EXISTS `medecin` (
  `idPro` int(11) NOT NULL AUTO_INCREMENT,
  `mdpPro` varchar(20) NOT NULL,
  `nomPro` varchar(50) NOT NULL,
  `prenomPro` varchar(50) NOT NULL,
  `specialisation` varchar(50) DEFAULT NULL,
  `cv` text,
  `courrielPro` varchar(50) DEFAULT NULL,
  `photo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idPro`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `medecin`
--

INSERT INTO `medecin` (`idPro`, `mdpPro`, `nomPro`, `prenomPro`, `specialisation`, `cv`, `courrielPro`, `photo`) VALUES
(1, '0000', 'Cabrol', 'Christian', 'cardiologue', 'Cabrol Christian 52 ans\r\n\r\n1 er a avoir greffe un coeur humain !', 'christian.cabrol@omnessante.fr', '1.jpg'),
(2, '0000', 'Random', 'Jean', 'osteopathe', 'Jean Random 65 ans\r\n\r\nEcole d\'osteopathe tres reputee avec diplome reconnu par l\'Etat. ', 'jean.random@omnessante.fr', '2.jpg'),
(3, '0000', 'Joab', 'Nadine', 'generaliste', 'Nadine Joab 42 ans\r\n\r\nMedecin generaliste diplomee de l\'universite de la Sorbonne. Ayant travaillé dans l\'hopital de Saint-Germain-en-Laye. ', 'nadine.joab@omnessante.fr', '3.jpg'),
(4, '0000', 'Trousselle', 'Isabelle', 'generaliste', 'Isabelle Trouselle 64 ans\r\n\r\nProfessionnelle de sante depuis plus de 20 ans ayant ete au contact de plus de centaines de milliers de patients différents, elle est le medecin dont vous avez besoin. ', 'isabelle.trousselle@omnessante.fr', '4.jpg'),
(5, '0000', 'Patin', 'Dider', 'generaliste', 'Didier Patin 56 ans\r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP. Conventionne secteur 2', 'didier.patin@omnessante.fr', '5.jpg'),
(6, '0000', 'Chabin', 'Antoine', 'generaliste', 'Antoine Chabin 36 ans\r\n\r\nFaculte de medecine de Paris UPMC. Interne à l APHP. Conventionne secteur 1', 'antoine.chabin@omnessante.fr', '6.jpg'),
(7, '0000', 'Sorre', 'Amandine', 'generaliste', 'Amandine Sorre 28 ans\r\n\r\nFaculte de medecine de Paris Diderot. Interne à l APHP. Conventionnee secteur 1', 'amandine.sorre@omnessante.fr', '7.jpg'),
(8, '0000', 'Hamoui', 'Farouk', 'generaliste', 'Farouk Hamoui 38 ans\r\n\r\nFaculte de medecine de Paris Saclay. Interne à l APHP. Conventionne secteur 2', 'farouk.hamoui@omnessante.fr', '8.jpg'),
(9, '0000', 'Lesage', 'Isabelle', 'generaliste', 'Isabelle Lesage 45 ans\r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP. Conventionne secteur 1', 'isabelle.lesage@omnessante.fr', '9.jpg'),
(10, '0000', 'Thomas', 'Paula', 'addictologue', 'Paula Thomas 26 ans\r\n\r\nFaculte de psychologie de Paris Descartes. Intervenante APHP', 'paula.thomas@omnessante.fr', '10.jpg'),
(11, '0000', 'Siboni', 'Laurent', 'addictologue', 'Laurent Siboni 41 ans\r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP.', 'laurent.siboni@omnessante.fr', '11.jpg'),
(12, '0000', 'Virag', 'Ronald', 'andrologue', 'Ronald Virag 64 ans\r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP. Conventionne secteur 2', 'ronald.virag@omnessante.fr', '12.jpg'),
(13, '0000', 'Aynaud', 'Olivier', 'andrologue', 'Olivier Aynaud 52 ans\r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP. Conventionne secteur 2', 'olivier.aynaud@omnessante.fr', '13.jpg'),
(14, '0000', 'Perlemuter', 'Katy', 'Cardiologue', 'Katy Perlemuter 45 ans\r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP. Cardiologue du sport. Conventionne secteur 2', 'katy.perlemuter@omnessante.fr', '14.jpg'),
(15, '0000', 'Durande', 'Maryse', 'dermatologue', 'Maryse Durande 63 ans \r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP. Consultation video possible. Conventionne secteur 2', 'maryse.durande@omnessante.fr', '15.jpg'),
(16, '0000', 'Rabbani', 'Alain', 'dermatologue', 'Alain Rabbani 55 ans \r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP. Cardiologue et venerologue. Conventionne secteur 1', 'alain.rabbani@omnessante.fr', '16.jpg'),
(17, '0000', 'Ramdani', 'Akli', 'gastro-hepato-enterologue', 'Akli Ramdani 43 ans\r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP. Conventionne secteur 1', 'akli.ramdani@omnessante.fr', '17.jpg'),
(18, '0000', 'Chollet', 'Robert', 'gastro-hepato-enterologue', 'Robert Chollet 54 ans \r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP. Conventionne secteur 2', 'robert.chollet@omnessante.fr', '18.jpg'),
(19, '0000', 'Chagnaud', 'Sophie', 'gynecologue', 'Sophie Chagnaud 32 ans \r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP. Conventionne secteur 2', 'sophie.chagnaud@omnessante.fr', '19.jpg'),
(20, '0000', 'Mimoun', 'Sylvain', 'gynecologue', 'Sylvain Mimoun 39 ans\r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP. Conventionne secteur 1', 'sylvain.mimoun@omnessante.fr', '20.jpg'),
(21, '0000', 'Pradelle', 'Mylene', 'i.s.t', 'Mylène Pradelle 43 ans\r\n\r\nFaculte de medecine de Paris Descartes. Interne à l APHP. Conventionne secteur 2', 'mylene.pradelle@omnessante.fr', '21.jpg'),
(22, '0000', 'Atlan', 'Alexandra', 'i.s.t', 'Alexandra Atlan 27 ans \r\n\r\nFaculte de medecine de Paris UPMC. Interne à l APHP. Conventionne secteur 2', 'alexandra.atlan@omnessante.fr', '22.jpg'),
(23, '0000', 'Jordan', 'Michael', 'osteopathie', 'Michael Jordan 50 ans \r\n\r\nEcole de kinesitherapie et d osteopathie.', 'michael.jordan@omnessante.fr', '23.jpg'),
(24, '0000', 'Bryant', 'Kobe', 'osteopathie', 'Kobe Bryant Eternel \r\n\r\nEcole de kinesitherapie et d osteopathie.', 'kobe.bryant@omnessante.fr', '24.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `patient`
--

DROP TABLE IF EXISTS `patient`;
CREATE TABLE IF NOT EXISTS `patient` (
  `logi` varchar(50) NOT NULL,
  `mdpClient` varchar(50) NOT NULL,
  `nomClient` varchar(50) NOT NULL,
  `prenomClient` varchar(50) NOT NULL,
  `adresseClient` varchar(50) DEFAULT NULL,
  `courrielClient` varchar(50) NOT NULL,
  `numSS` varchar(50) NOT NULL,
  `numeroClient` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`numeroClient`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `patient`
--

INSERT INTO `patient` (`logi`, `mdpClient`, `nomClient`, `prenomClient`, `adresseClient`, `courrielClient`, `numSS`, `numeroClient`) VALUES
('Jaqueline', '0000', 'Dupont', 'Jaqueline', '12 rue du Pommier 92 000 Nanterre', 'jaqueline.dupont@gmail.com', '2 70 07 75 123 456 22', 1),
('Charles', '1111', 'Fred', 'Charles', '67 rue Pierre Currie 78 000 Montesson', 'charles.fred@gmail.com', '1 70 07 75 123 456 22', 2),
('Christophe', '2222', 'Vallet', 'Christophe', '20 boulevard Renoir 50 201 Somewhere', 'christophe.vallet@gmail.com', '1 95 02 75 102 365 ', 3),
('Melina', '3333', 'Karapetian', 'Melina', '\r\n54 Rue Philippe de Girard 75018 Paris', 'melina.karapetian@gmail.com', '2 68 10 75 109 335 ', 4),
('Simon', '4444', 'Dudamel', 'Simon', '\r\n44 Rue du general Foy 75008 Paris', 'simon.dudamel@gmail.com', '1 48 10 75 109 335 ', 5),
('Antoine', '5555', 'Breton', 'Antoine', '\r\n44 Avenue Foch 92250 La Garenne Colombes', 'antoine.breton@gmail.com', '1 90 10 75 009 102 ', 6),
('Patricia', '6666', 'Pisanu', 'Patricia', '\r\n188 rue du Faubourg Saint Denis 75010 Paris', 'patricia.pisanu@gmail.com', '2 66 09 75 109 111 ', 7),
('Lucas', '7777', 'Dupleissier', 'Lucas', '\r\n17 rue Stevenson 91540 Mennecy', 'lucas.dupleissier@gmail.com', '1 99 01 75 106 002 ', 8);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
