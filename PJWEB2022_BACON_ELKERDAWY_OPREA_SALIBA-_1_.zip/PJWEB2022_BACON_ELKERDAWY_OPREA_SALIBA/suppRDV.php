<?php
session_start();
$database = new PDO('mysql:host=localhost;dbname=projet;', 'root','mdppoo');
$rdv=$_GET['supp'];
$suppression="UPDATE `consultation` SET `client` = NULL WHERE `consultation`.`numeroCons` = '". $rdv."';";
$database->query($suppression);
header('Location:RDV.php');
?>
